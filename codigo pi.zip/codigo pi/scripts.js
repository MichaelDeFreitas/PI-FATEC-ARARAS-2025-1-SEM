const tarifasFixas = {
    tipoCarga: {
        normal: 1.0,
        fragil: 1.2,
        volumosa: 1.5
    },
    valorKm: 2.5,   // base por km
    valorPeso: 0.5  // valor adicional por kg
};

// Obtém os valores de peso e tipo de carga
const peso = parseFloat(document.getElementById("peso").value) || 0;
const tipo = document.getElementById("tipoCarga").value;

// Função para calcular o valor do frete
function calcularFrete() {
    // Distâncias entre cidades específicas (em km)
    const distancias = {
        "São Paulo - Campinas": 100,
        "São Paulo - Leme": 80,
        "São Paulo - Limeira": 430,
        "Campinas - Santos": 150
    };

    // Valores base por km e tipo de carga
    const valorPorKm = {
        "leve": 1.5, // R$ por km para cargas leves
        "pesada": 2.5 // R$ por km para cargas pesadas
    };

    // Obtém a cidade selecionada
    const cidade = document.getElementById("cidade").value;

    // Verifica se a cidade está no mapa de distâncias
    if (!distancias[cidade]) {
        alert("Selecione uma rota válida.");
        return;
    }

    // Calcula a distância e o valor do frete
    const kmRodados = distancias[cidade];
    const valorFrete = kmRodados * (valorPorKm[tipo] || 0) * peso;

    // Exibe os resultados no elemento de resultado
    const resultado = document.getElementById("resultadoFrete");
    resultado.innerHTML = `
        <p><strong>Rota:</strong> ${cidade}</p>
        <p><strong>Quilômetros Rodados:</strong> ${kmRodados} km</p>
        <p><strong>Valor do Frete:</strong> R$ ${valorFrete.toFixed(2)}</p>
    `;
}

// Adiciona o evento ao botão de calcular
document.getElementById("calcular").addEventListener("click", calcularFrete);

function calcularFreteComplexo() {
    const origem = document.getElementById("origem").value;
    const destino = document.getElementById("destino").value;

    if (!origem || !destino) {
        alert("Por favor, preencha origem e destino.");
        return;
    }
    if (origem === destino) {
        document.getElementById("resultadoFrete").innerText = "Origem e destino iguais => frete R$ 0,00";
        return;
    }

    // usar API de mapas para pegar distância real
    const directionsService = new google.maps.DirectionsService();

    directionsService.route({
        origin: origem,
        destination: destino,
        travelMode: 'DRIVING'
    }, (response, status) => {
        if (status === 'OK') {
            const distanceMeters = response.routes[0].legs[0].distance.value;
            const distanceKm = distanceMeters / 1000;

            const tarifaCarga = tarifasFixas.tipoCarga[tipo];
            const custoBase = distanceKm * tarifasFixas.valorKm;
            const custoPeso = peso * tarifasFixas.valorPeso;
            const total = (custoBase + custoPeso) * tarifaCarga;

            document.getElementById("resultadoFrete").innerText =
                `Distância: ${distanceKm.toFixed(1)} km\n` +
                `Tipo de carga: ${tipo} (x${tarifaCarga.toFixed(2)})\n` +
                `Peso: ${peso} kg\n` +
                `Custo base (km): R$ ${(custoBase).toFixed(2)}\n` +
                `Custo pelo peso: R$ ${(custoPeso).toFixed(2)}\n` +
                `Valor total estimado: R$ ${total.toFixed(2)}`;

            // mostrar mapa
            initMap(response);
        } else {
            alert("Não foi possível calcular a rota: " + status);
        }
    });
}

function initMap(directionsResult) {
    const map = new google.maps.Map(document.getElementById("mapa"), {
        zoom: 7,
        center: { lat: -22.752, lng: -47.9 }  // um centro aproximado; ajustar para sua região
    });
    const directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(map);
    directionsRenderer.setDirections(directionsResult);
}